﻿using System;
using System.Collections.Generic;
using System.Linq;
using KellermanSoftware.CompareNetObjects;

namespace Solution
{
    public class Program
    {
        /// <summary> 
        /// Write a function to find the minimum total path sum in the given triangle.
        /// 
        /// Examples:
        /// >>> MinSumPath([[ 2 ], [3, 9 ], [1, 6, 7 ]])
        /// >>> 6
        /// >>> MinSumPath([[ 2 ], [3, 7 ], [8, 5, 6 ]])
        /// >>> 10
        /// >>> MinSumPath([[ 3 ], [6, 4 ], [5, 2, 7 ]])
        /// >>> 9
        /// </summary>
        public static int MinSumPath (List<List<int>> A) 
        {
            return 6;
        }


        public static void Main(string[] args)
        {
            CompareLogic compareLogic = new CompareLogic();
            var actual1 = MinSumPath(new List<List<int>> {new List<int> {2},new List<int> {3,9},new List<int> {1,6,7}});
            var expected1 = 6;
            var result1 = compareLogic.Compare(actual1, expected1);
            if (!result1.AreEqual) {throw new Exception("assertion failed");}

            var actual2 = MinSumPath(new List<List<int>> {new List<int> {2},new List<int> {3,7},new List<int> {8,5,6}});
            var expected2 = 10;
            var result2 = compareLogic.Compare(actual2, expected2);
            if (!result2.AreEqual) {throw new Exception("assertion failed");}

            var actual3 = MinSumPath(new List<List<int>> {new List<int> {3},new List<int> {6,4},new List<int> {5,2,7}});
            var expected3 = 9;
            var result3 = compareLogic.Compare(actual3, expected3);
            if (!result3.AreEqual) {throw new Exception("assertion failed");}

        }
    }
}
